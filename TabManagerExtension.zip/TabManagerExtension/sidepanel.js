document.addEventListener('DOMContentLoaded', async () => {
    const tabsContainer = document.getElementById('tabs-container');
    const groupsContainer = document.getElementById('groups-container');
    const createGroupButton = document.getElementById('create-group');

    // Function to create a new group
    function createGroup(tabs = []) {
        const groupElement = document.createElement('div');
        groupElement.className = 'group';

        const groupHeader = document.createElement('div');
        groupHeader.className = 'group-header';

        const groupTitle = document.createElement('div');
        groupTitle.className = 'group-title';
        groupTitle.textContent = 'New Group';
        groupTitle.contentEditable = true;

        const shrinkButton = document.createElement('span');
        shrinkButton.className = 'shrink-button';
        shrinkButton.textContent = '-';

        groupHeader.appendChild(groupTitle);
        groupHeader.appendChild(shrinkButton);
        groupElement.appendChild(groupHeader);
        groupsContainer.appendChild(groupElement);

        // Add tabs to the group
        tabs.forEach(tabElement => {
            tabElement.classList.add('dropped');
            groupElement.appendChild(tabElement);
        });

        // Add drop event listeners
        groupElement.addEventListener('dragover', (e) => {
            e.preventDefault();
        });

        groupElement.addEventListener('drop', (e) => {
            e.preventDefault();
            const tabId = e.dataTransfer.getData('text/plain');
            const tabElement = document.querySelector(`[data-tab-id="${tabId}"]`);
            tabElement.classList.add('dropped');
            groupElement.appendChild(tabElement);
        });

        // Add click event listener to shrink button
        shrinkButton.addEventListener('click', () => {
            groupElement.classList.toggle('shrunk');
            shrinkButton.textContent = groupElement.classList.contains('shrunk') ? '+' : '-';
        });
    }

    // Fetch all open tabs
    const tabs = await chrome.tabs.query({});
    tabs.forEach(tab => {
        const tabElement = document.createElement('div');
        tabElement.className = 'tab';
        tabElement.draggable = true;
        tabElement.dataset.tabId = tab.id;
        tabElement.dataset.tabUrl = tab.url;

        // Create favicon element
        const faviconElement = document.createElement('img');
        faviconElement.src = tab.favIconUrl || 'default-favicon.png'; // Use a default favicon if none is available
        faviconElement.alt = 'Favicon';
        faviconElement.className = 'favicon';

        // Create title element
        const titleElement = document.createElement('div');
        titleElement.className = 'tab-title';
        titleElement.textContent = tab.title;

        // Append favicon and title to tab element
        tabElement.appendChild(faviconElement);
        tabElement.appendChild(titleElement);

        tabsContainer.appendChild(tabElement);

        // Add drag event listeners
        tabElement.addEventListener('dragstart', (e) => {
            e.dataTransfer.setData('text/plain', tabElement.dataset.tabId);
        });

        tabElement.addEventListener('dragover', (e) => {
            e.preventDefault();
        });

        tabElement.addEventListener('drop', (e) => {
            e.preventDefault();
            const tabId = e.dataTransfer.getData('text/plain');
            const draggedTabElement = document.querySelector(`[data-tab-id="${tabId}"]`);
            if (draggedTabElement !== tabElement) {
                createGroup([draggedTabElement, tabElement]);
            }
        });

        // Add double-click event listener to open the tab
        tabElement.addEventListener('dblclick', async () => {
            const tabId = parseInt(tabElement.dataset.tabId, 10);
            const tabUrl = tabElement.dataset.tabUrl;

            // Check if the tab is already open
            const existingTab = await chrome.tabs.get(tabId).catch(() => null);
            if (existingTab) {
                // If the tab is open, focus it
                chrome.tabs.update(tabId, { active: true });
            } else {
                // If the tab is not open, open a new tab with the URL
                chrome.tabs.create({ url: tabUrl });
            }
        });
    });

    // Create new group button event listener
    createGroupButton.addEventListener('click', () => {
        createGroup();
    });
});